﻿using System;
using System.Collections.Generic;

namespace Exam4
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Animals> animals = DataLoader.Load();
            
            animals.Sort(new Sort());
            int index = 1;
            foreach (var VARIABLE in animals)
            {
               
                Console.WriteLine($"{ index++} {VARIABLE}");
            }
            AnimalAction.ChooseOverDueAction(animals);
            foreach (var g in animals)
            {
                g.EventStart();
                
            }
            AnimalAction.ChooseAction(animals);
            DataLoader.Save(animals);
            int index1 = 1;
            foreach (var VARIABLE in animals)
            {
                Console.WriteLine($"{index1} {VARIABLE}");
            }



            Console.ReadKey();
        
        }
    }
}
