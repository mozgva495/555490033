﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Newtonsoft.Json;

namespace Exam4
{
    public class DataLoader

    {

        const string directory = "../../Data";

        const string fileName = " Animals.json";

        public static void Save(List<Animals> animals)
        {
            string json = JsonConvert.SerializeObject(animals, Formatting.Indented );
            SaveFile(json);
        }
        public static List<Animals> Load()
        {
            string path = Path.Combine("..", "..", "Data");
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            try
            {
                string content = File.ReadAllText(Path.Combine(path, fileName));
                if (string.IsNullOrEmpty(content))
                {
                    return new List<Animals>();
                }

                List<Animals> animals = JsonConvert.DeserializeObject<List<Animals>>(content);
               
                return animals;
            }
            catch (DirectoryNotFoundException)
            {
                Console.WriteLine($"Отсутствует директория {directory}");
                return new List<Animals>();
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine($"Отсутствует файл {fileName}");
                return new List<Animals>();
            }
            catch (ApplicationException ex)
            {
                Console.WriteLine(ex.Message);
                return new List<Animals>();
            }
        }
        private static void SaveFile(string content)
        {
            try
            {
                File.WriteAllText($"{directory}/{fileName}", content);
            }
            catch (DirectoryNotFoundException)
            {
                Directory.CreateDirectory(directory);
                SaveFile(content);
            }

        }

    }
}
