﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace Exam4
{
    public class Animals
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public int SatietyLevel { get; set; }
        public int MoodLevel { get; set; }
        public int HealthLevel { get; set; }
        public double SortAnimal
        {
            get
            {
                return (SatietyLevel + MoodLevel + HealthLevel) / 3;
            }
        }

        [JsonIgnore]
        public Istrategy AnimalStrategy { get; set; }
        

        Random rnd = new Random();
        public event Action<Animals> EventAction;


        public Animals(string name, int age)
        {
            Name = name;
            Age = age;
            
        
            if (Age < 5)
                AnimalStrategy = new YoungStrategy();
        
            if (Age >= 6 || Age < 10)
            {
                AnimalStrategy = new AdulStrategy();
            }
            if (Age > 10)
            {
                AnimalStrategy = new OldStrategy();
            }
        }

        public void EventStart()
        {
            if (EventAction != null)
            {
                EventAction(this);
            }
        }
        
        public override string ToString()
        {
            return $"Имя {Name} \tВозраст {Age} \tСытость {SatietyLevel}\tНастроение {MoodLevel} \tЗдаровье {HealthLevel}\t {EventAction}";
        }

        public void ToFeed()
        {
           
            int number = 1;
            if (number == rnd.Next(6))
            {
                MoodLevel -= 5;
                SatietyLevel -= 5;
                Console.WriteLine("Ваше животное отравилось\n");
            }
            else
            {
                AnimalStrategy.ToFeed(this);
                Print("Вы покормили животное\n ");
            }
           

        }
        public void ToPlay()
        {
            
            int number = 2;
            if (number == rnd.Next(5))
            {
                MoodLevel -= 5;
                HealthLevel -= 5;
                Console.WriteLine("Ваше животное получило травму\n");
            }
            else
            {
                AnimalStrategy.ToPlay(this);
                Print("Вы поиграли с животным \n");

            }
            
        }
        public void ToFreat()
        {
            int number = 3;
            if (number == rnd.Next(5))
            {
                Console.WriteLine("Ваше животное не выздоравило\n");
            }
            else
            {
                AnimalStrategy.ToFreat(this);
                Print("Вы вылечили животное ");
            }
        }

        public void Print(string mesage)
        {
            Console.WriteLine(mesage);
        }

        
        
    }

    public class Sort : IComparer<Animals>
    {
      

        public int Compare(Animals x, Animals y)
        {
            
                return x.SortAnimal.CompareTo(y.SortAnimal);
            
        }
    }

   

}
