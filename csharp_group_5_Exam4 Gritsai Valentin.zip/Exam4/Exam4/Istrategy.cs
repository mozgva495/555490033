﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exam4
{
    public interface Istrategy
    {
        void ToFeed(Animals animals);
        void ToPlay(Animals animals);
        void ToFreat(Animals animals);
    }

    public class YoungStrategy : Istrategy
    {
        public void ToFeed(Animals animals)
        {
            animals.SatietyLevel += 10;
            animals.MoodLevel += 10;
            animals.HealthLevel += 10;
        }

        public void ToPlay(Animals animals)
        {
            animals.SatietyLevel -= 2;
            animals.MoodLevel += 10;
            animals.HealthLevel += 10;
        }

        public void ToFreat(Animals animals)
        {
            animals.MoodLevel += 10;
            animals.HealthLevel += 10;
        }
    }

    public class AdulStrategy : Istrategy
    {
        public void ToFeed(Animals animals)
        {
            animals.SatietyLevel += 5;
            animals.MoodLevel += 5;
            animals.HealthLevel += 5;
        }

        public void ToPlay(Animals animals)
        {
            animals.SatietyLevel -= 5;
            animals.MoodLevel += 5;
            animals.HealthLevel += 5;
        }

        public void ToFreat(Animals animals)
        {
          
            animals.MoodLevel += 5;
            animals.HealthLevel += 5;
        }
    }
    public class OldStrategy : Istrategy
    {
        public void ToFeed(Animals animals)
        {
            animals.SatietyLevel += 2;
            animals.MoodLevel += 2;
            animals.HealthLevel += 2;
        }

        public void ToPlay(Animals animals)
        {
            animals.SatietyLevel -= 10;
            animals.MoodLevel += 2;
            animals.HealthLevel += 2;
        }

        public void ToFreat(Animals animals)
        {
          
            animals.MoodLevel += 2;
            animals.HealthLevel += 2;
        }
    }
    
}
