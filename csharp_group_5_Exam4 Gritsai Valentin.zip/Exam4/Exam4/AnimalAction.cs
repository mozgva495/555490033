﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exam4
{
    public class AnimalAction
    {
        public static void ChooseAction(List<Animals> animals)

        {
            Console.WriteLine(" выбири действие:\n 1 - довить животного \n2 - Выбрать животного");
            int action = int.Parse(Console.ReadLine());

            switch (action)
            {
                case 1:
                    EnterAnimal(animals); break;
                case 2:
                    var animal = ChooseAnimals(animals);
                    ChooseAction(animal); break;


            }
        }
        public static Animals ChooseAnimals(List<Animals> animals)
        {
            Console.WriteLine("Введите номер животного ");
            
            int index = Convert.ToInt32(Console.ReadLine());
            if (index <= animals.Count)
            {
                Console.WriteLine($"Животное -  {animals[index - 1]}");
               
                return animals[index -1];
            }
            else
            {
                Console.WriteLine("Введен не верный номер ");
                return ChooseAnimals(animals);
            }
        }
        public static void ChooseAction(Animals animals)
        {
            
            Console.WriteLine("1 - покормить\n2 - Поиграть\n3 - Лечить");
            
            try
            {
                int number = Convert.ToInt32(Console.ReadLine());
                if (number > 0 || number > 3)
                {
                    switch (number)
                    {
                        case 1:
                            
                            animals.ToFeed();
                           
                            break;
                        case 2:
                           
                            animals.ToPlay();
                           
                            break;
                        case 3:
                            
                            animals.ToFreat();
                           
                            break;

                        default:
                            Console.WriteLine("Ничего не введено");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Введено неверное значение операции");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Введено не верное значение\n ");
                
            }
        }

        private static void EnterAnimal(List<Animals> animals)
        {
            try
            {
                string name = EnterAnimalNeme();
                int age = EnterAnimalAge();
               
                Animals myAnimals = new Animals(name, age);
                animals.Add(myAnimals);
                DataLoader.Save(animals);
                ChooseAction(animals);
            }
            catch (ApplicationException e)
            {
                Console.WriteLine(e);
                EnterAnimal(animals);
            }
        }

        private static string EnterAnimalNeme()
        {
            Console.WriteLine(" Введите имя животного");
            string name = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(name))
            {
                throw new ApplicationException("Пустое имя");
            }

            return name;
        }
        private static int EnterAnimalAge()
        {
            Console.WriteLine(" Введите возраст");
            int age = 0;
            try
            {
                age = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException )
            {

                throw new ApplicationException("Неверный формат числа ");
            }
            return age;
        }
        
        public static void ChooseOverDueAction(List<Animals> animals)
        {
            foreach (var s in animals)
            {
                if (s.SatietyLevel <= 0 || s.MoodLevel <= 0 || s.HealthLevel <= 0)
                {
                   
                    {
                        EventAction.HungryAnimal(s);
                    }
                }
                else if (s.SatietyLevel >= 10|| s.MoodLevel >= 10 || s.HealthLevel >= 10)
                {
                    EventAction.OvereatingAnimal(s);
                }
            }
           

        }

        
    }
}
