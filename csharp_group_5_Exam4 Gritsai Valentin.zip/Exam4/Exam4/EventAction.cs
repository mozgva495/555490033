﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exam4
{
    public class EventAction
    {
        public static void HungryAnimal(Animals animals)
        {
            Console.WriteLine($"{animals.Name} Голоден накормите ");
        }
        public static void OvereatingAnimal(Animals animals)
        {
            Console.WriteLine($" {animals.Name} Больше кушать не могу ");
        }

    
    }
}
